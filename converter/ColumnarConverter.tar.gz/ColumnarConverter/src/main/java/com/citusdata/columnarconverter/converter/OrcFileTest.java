package com.citusdata.columnarconverter.converter;

import au.com.bytecode.opencsv.CSVReader;

import java.io.BufferedReader;

import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.conf.HiveConf;
import org.apache.hadoop.hive.ql.io.orc.*;

/**
 * Sample class for converting CSV files into the ORC format.
 *
 * First the class that represents the table should be created. Then the ORC
 * writer could be created by a Java object inspector for this class. After
 * that, for each row an object should be created by initializing its fields
 * with the values in the corresponding line in the CSV file.
 *
 * Parameters that could be given to the writer are described below:
 *
 * stripeSize = Size of the row chunk to be written in the file in columnar
 * fashion.
 *
 * compressBlockSize = Compression block size that is used when compressing a
 * column.
 *
 * compressionKind = Kind of the compression. Currently Snappy, GZIP and
 * uncompressed files are supported in the foreign data wrapper.
 *
 * rowIndexStride = Number of rows to create an index entry for. Index entries
 * contain the minimum & maximum values of the following (rowIndexStride)
 * columns and this enable skipping rows that doesn't contain the value we are
 * looking for
 *
 * The following classes and functions convert the TPC-H tables into the ORC
 * format. These can be used for reference when converting another table.
 */
public class OrcFileTest {

    /* locations of the input and output files */
    private static String tpchLocation = "/home/gokhan/Downloads/tpch_2_13_0/";
    private static String outputLocation = "/home/gokhan/orc-files/";
    
    /* writer parameters */
    private static int stripeSize = 268435456;
    private static int compressBlockSize = 262144;
    private static CompressionKind compressionKind = CompressionKind.NONE;
    private static int rowIndexStride = 10000;
    
    /* private fields that are used when converting the files */
    private static Calendar calendar = Calendar.getInstance(TimeZone
            .getTimeZone("UTC"));
    private CSVReader csvReader;
    private java.io.Reader fileReader;
    private Configuration conf;
    private FileSystem fs;
    private Path testFilePath;

    static {
        calendar.clear();
        calendar.set(2000, 0, 1, 0, 0, 0);
    }

    public static void main(String args[]) {
        try {
            OrcFileTest d = new OrcFileTest();
            d.writePartFile();
            d.writeSupplierFile();
            d.writePartSuppFile();
            d.writeCustomerFile();
            d.writeOrdersFile();
            d.writeNationFile();
            d.writeRegionFile();
            d.writeLineitemFile();
        } catch (Exception ex) {
            Logger.getLogger(OrcFileTest.class.getName()).log(Level.SEVERE,
                    null, ex);
        }

    }

    public OrcFileTest() throws IOException {
        conf = new HiveConf();
        fs = FileSystem.getLocal(conf);
    }

    public CSVReader getCSVReader(String filePath) throws FileNotFoundException {
        fileReader = new BufferedReader(new FileReader(filePath));
        csvReader = new CSVReader(fileReader, '|');
        return csvReader;
    }

    public void closeFiles() throws IOException {
        csvReader.close();
        fileReader.close();
    }

    public static class Part {

        long P_PARTKEY;
        String P_NAME;
        String P_MFGR;
        String P_BRAND;
        String P_TYPE;
        int P_SIZE;
        String P_CONTAINER;
        double P_RETAILPRICE;
        String P_COMMENT;

        public Part(long P_PARTKEY, String P_NAME, String P_MFGR,
                String P_BRAND, String P_TYPE, int P_SIZE, String P_CONTAINER,
                double P_RETAILPRICE, String P_COMMENT) {
            this.P_PARTKEY = P_PARTKEY;
            this.P_NAME = P_NAME;
            this.P_MFGR = P_MFGR;
            this.P_BRAND = P_BRAND;
            this.P_TYPE = P_TYPE;
            this.P_SIZE = P_SIZE;
            this.P_CONTAINER = P_CONTAINER;
            this.P_RETAILPRICE = P_RETAILPRICE;
            this.P_COMMENT = P_COMMENT;
        }

        public Part(String[] fields) {
            this(Long.parseLong(fields[0]), fields[1], fields[2], fields[3],
                    fields[4], Integer.parseInt(fields[5]), fields[6], Double
                    .parseDouble(fields[7]), fields[8]);
        }
    }

    public static class Supplier {

        long S_SUPPKEY;
        String S_NAME;
        String S_ADDRESS;
        long S_NATIONKEY;
        String S_PHONE;
        double S_ACCTBAL;
        String S_COMMENT;

        public Supplier(long S_SUPPKEY, String S_NAME, String S_ADDRESS,
                long S_NATIONKEY, String S_PHONE, double S_ACCTBAL,
                String S_COMMENT) {
            this.S_SUPPKEY = S_SUPPKEY;
            this.S_NAME = S_NAME;
            this.S_ADDRESS = S_ADDRESS;
            this.S_NATIONKEY = S_NATIONKEY;
            this.S_PHONE = S_PHONE;
            this.S_ACCTBAL = S_ACCTBAL;
            this.S_COMMENT = S_COMMENT;
        }

        public Supplier(String[] fields) {
            this(Long.parseLong(fields[0]), fields[1], fields[2], Long
                    .parseLong(fields[3]), fields[4], Double
                    .parseDouble(fields[5]), fields[6]);
        }
    }

    public static class PartSupp {

        long PS_PARTKEY;
        long PS_SUPPKEY;
        int PS_AVAILQTY;
        double PS_SUPPLYCOST;
        String PS_COMMENT;

        public PartSupp(long PS_PARTKEY, long PS_SUPPKEY, int PS_AVAILQTY,
                double PS_SUPPLYCOST, String PS_COMMENT) {
            this.PS_PARTKEY = PS_PARTKEY;
            this.PS_SUPPKEY = PS_SUPPKEY;
            this.PS_AVAILQTY = PS_AVAILQTY;
            this.PS_SUPPLYCOST = PS_SUPPLYCOST;
            this.PS_COMMENT = PS_COMMENT;
        }

        public PartSupp(String[] fields) {
            this(Long.parseLong(fields[0]), Long.parseLong(fields[1]), Integer
                    .parseInt(fields[2]), Double.parseDouble(fields[3]),
                    fields[4]);
        }
    }

    public static class Customer {

        long C_CUSTKEY;
        String C_NAME;
        String C_ADDRESS;
        long C_NATIONKEY;
        String C_PHONE;
        double C_ACCTBAL;
        String C_MKTSEGMENT;
        String C_COMMENT;

        public Customer(long C_CUSTKEY, String C_NAME, String C_ADDRESS,
                long C_NATIONKEY, String C_PHONE, double C_ACCTBAL,
                String C_MKTSEGMENT, String C_COMMENT) {
            this.C_CUSTKEY = C_CUSTKEY;
            this.C_NAME = C_NAME;
            this.C_ADDRESS = C_ADDRESS;
            this.C_NATIONKEY = C_NATIONKEY;
            this.C_PHONE = C_PHONE;
            this.C_ACCTBAL = C_ACCTBAL;
            this.C_MKTSEGMENT = C_MKTSEGMENT;
            this.C_COMMENT = C_COMMENT;
        }

        public Customer(String[] fields) {
            this(Long.parseLong(fields[0]), fields[1], fields[2], Long
                    .parseLong(fields[3]), fields[4], Double
                    .parseDouble(fields[5]), fields[6], fields[7]);
        }
    }

    public static class Orders {

        long O_ORDERKEY;
        long O_CUSTKEY;
        String O_ORDERSTATUS;
        double O_TOTALPRICE;
        Date O_ORDERDATE;
        String O_ORDERPRIORITY;
        String O_CLERK;
        int O_SHIPPRIORITY;
        String O_COMMENT;

        public Orders(long O_ORDERKEY, long O_CUSTKEY, String O_ORDERSTATUS,
                double O_TOTALPRICE, Date O_ORDERDATE,
                String O_ORDERPRIORITY, String O_CLERK, int O_SHIPPRIORITY,
                String O_COMMENT) {
            this.O_ORDERKEY = O_ORDERKEY;
            this.O_CUSTKEY = O_CUSTKEY;
            this.O_ORDERSTATUS = O_ORDERSTATUS;
            this.O_TOTALPRICE = O_TOTALPRICE;
            this.O_ORDERDATE = O_ORDERDATE;
            this.O_ORDERPRIORITY = O_ORDERPRIORITY;
            this.O_CLERK = O_CLERK;
            this.O_SHIPPRIORITY = O_SHIPPRIORITY;
            this.O_COMMENT = O_COMMENT;
        }

        public Orders(String[] fields) {
            this(Long.parseLong(fields[0]), Long.parseLong(fields[1]),
                    fields[2], Double.parseDouble(fields[3]),
                    parseDateFromFields(fields[4]), fields[5], fields[6],
                    Integer.parseInt(fields[7]), fields[8]);
        }
    }

    public static class Nation {

        long N_NATIONKEY;
        String N_NAME;
        long N_REGIONKEY;
        String N_COMMENT;

        public Nation(long N_NATIONKEY, String N_NAME, long N_REGIONKEY,
                String N_COMMENT) {
            this.N_NATIONKEY = N_NATIONKEY;
            this.N_NAME = N_NAME;
            this.N_REGIONKEY = N_REGIONKEY;
            this.N_COMMENT = N_COMMENT;
        }

        public Nation(String[] fields) {
            this(Long.parseLong(fields[0]), fields[1], Long
                    .parseLong(fields[2]), fields[3]);
        }
    }

    public static class Region {

        long R_REGIONKEY;
        String R_NAME;
        String R_COMMENT;

        public Region(long R_REGIONKEY, String R_NAME, String R_COMMENT) {
            this.R_REGIONKEY = R_REGIONKEY;
            this.R_NAME = R_NAME;
            this.R_COMMENT = R_COMMENT;
        }

        public Region(String[] fields) {
            this(Long.parseLong(fields[0]), fields[1], fields[2]);
        }
    }

    public static class Lineitem {

        long l_orderkey;
        long l_partkey;
        long l_suppkey;
        int l_linenumber;
        double l_quantity;
        double l_extendedprice;
        double l_discount;
        double l_tax;
        String l_returnflag;
        String l_linestatus;
        Date l_shipdate;
        Date l_commitdate;
        Date l_receiptdate;
        String l_shipinstruct;
        String l_shipmode;
        String l_comment;

        public Lineitem(long l_orderkey, long l_partkey, long l_suppkey,
                int l_linenumber, double l_quantity, double l_extendedprice,
                double l_discount, double l_tax, String l_returnflag,
                String l_linestatus, Date l_shipdate,
                Date l_commitdate, Date l_receiptdate,
                String l_shipinstruct, String l_shipmode, String l_comment) {
            this.l_orderkey = l_orderkey;
            this.l_partkey = l_partkey;
            this.l_suppkey = l_suppkey;
            this.l_linenumber = l_linenumber;
            this.l_quantity = l_quantity;
            this.l_extendedprice = l_extendedprice;
            this.l_discount = l_discount;
            this.l_tax = l_tax;
            this.l_returnflag = l_returnflag;
            this.l_linestatus = l_linestatus;
            this.l_shipdate = l_shipdate;
            this.l_commitdate = l_commitdate;
            this.l_receiptdate = l_receiptdate;
            this.l_shipinstruct = l_shipinstruct;
            this.l_shipmode = l_shipmode;
            this.l_comment = l_comment;
        }

        public Lineitem(String[] fields) throws ParseException {
            this(Long.parseLong(fields[0]), Long.parseLong(fields[1]), Long
                    .parseLong(fields[2]), Integer.parseInt(fields[3]), Double
                    .parseDouble(fields[4]), Double.parseDouble(fields[5]),
                    Double.parseDouble(fields[6]), Double
                    .parseDouble(fields[7]), fields[8], fields[9],
                    parseDateFromFields(fields[10]),
                    parseDateFromFields(fields[11]),
                    parseDateFromFields(fields[12]), fields[13],
                    fields[14], fields[15]);
        }
    }

    public void writePartFile() throws Exception {
        String tablePath = tpchLocation + "part.tbl";
        testFilePath = new Path(outputLocation + "part.orc");
        fs.delete(testFilePath, false);

        ObjectInspector inspector;

        String[] fields;
        Part row;

        synchronized (OrcFileTest.class) {
            inspector = ObjectInspectorFactory.getReflectionObjectInspector(
                    Part.class,
                    ObjectInspectorFactory.ObjectInspectorOptions.JAVA);
        }
        Writer writer = OrcFile.createWriter(fs, testFilePath, conf, inspector,
                stripeSize, compressionKind, compressBlockSize, rowIndexStride);

        csvReader = getCSVReader(tablePath);
        while ((fields = csvReader.readNext()) != null) {
            if (fields != null) {
                row = new Part(fields);
                writer.addRow(row);
            }
        }
        writer.close();
        closeFiles();
        System.out.println("Part: DONE");
    }

    public void writeSupplierFile() throws Exception {
        String tablePath = tpchLocation + "supplier.tbl";
        testFilePath = new Path(outputLocation + "supplier.orc");
        fs.delete(testFilePath, false);

        ObjectInspector inspector;

        String[] fields;
        Supplier row;

        synchronized (OrcFileTest.class) {
            inspector = ObjectInspectorFactory.getReflectionObjectInspector(
                    Supplier.class,
                    ObjectInspectorFactory.ObjectInspectorOptions.JAVA);
        }
        Writer writer = OrcFile.createWriter(fs, testFilePath, conf, inspector,
                stripeSize, compressionKind, compressBlockSize, 0);

        csvReader = getCSVReader(tablePath);
        while ((fields = csvReader.readNext()) != null) {
            if (fields != null) {
                row = new Supplier(fields);
                writer.addRow(row);
            }
        }
        writer.close();
        closeFiles();
        System.out.println("Supplier: DONE");
    }

    public void writePartSuppFile() throws Exception {
        String tablePath = tpchLocation + "partsupp.tbl";
        testFilePath = new Path(outputLocation + "partsupp.orc");
        fs.delete(testFilePath, false);

        ObjectInspector inspector;

        String[] fields;
        PartSupp row;

        synchronized (OrcFileTest.class) {
            inspector = ObjectInspectorFactory.getReflectionObjectInspector(
                    PartSupp.class,
                    ObjectInspectorFactory.ObjectInspectorOptions.JAVA);
        }
        Writer writer = OrcFile.createWriter(fs, testFilePath, conf, inspector,
                stripeSize, compressionKind, compressBlockSize, rowIndexStride);

        csvReader = getCSVReader(tablePath);
        while ((fields = csvReader.readNext()) != null) {
            if (fields != null) {
                row = new PartSupp(fields);
                writer.addRow(row);
            }
        }
        writer.close();
        closeFiles();
        System.out.println("PartSupp: DONE");
    }

    public void writeCustomerFile() throws Exception {
        String tablePath = tpchLocation + "customer.tbl";
        testFilePath = new Path(outputLocation + "customer.orc");
        fs.delete(testFilePath, false);

        ObjectInspector inspector;

        String[] fields;
        Customer row;

        synchronized (OrcFileTest.class) {
            inspector = ObjectInspectorFactory.getReflectionObjectInspector(
                    Customer.class,
                    ObjectInspectorFactory.ObjectInspectorOptions.JAVA);
        }
        Writer writer = OrcFile.createWriter(fs, testFilePath, conf, inspector,
                stripeSize, compressionKind, compressBlockSize, rowIndexStride);

        csvReader = getCSVReader(tablePath);
        while ((fields = csvReader.readNext()) != null) {
            if (fields != null) {
                row = new Customer(fields);
                writer.addRow(row);
            }
        }
        writer.close();
        closeFiles();
        System.out.println("Customer: DONE");
    }

    public void writeOrdersFile() throws Exception {
        String tablePath = tpchLocation + "orders.tbl";
        testFilePath = new Path(outputLocation + "orders.orc");
        fs.delete(testFilePath, false);

        ObjectInspector inspector;

        String[] fields;
        Orders row;

        synchronized (OrcFileTest.class) {
            inspector = ObjectInspectorFactory.getReflectionObjectInspector(
                    Orders.class,
                    ObjectInspectorFactory.ObjectInspectorOptions.JAVA);
        }
        Writer writer = OrcFile.createWriter(fs, testFilePath, conf, inspector,
                stripeSize, compressionKind, compressBlockSize, rowIndexStride);

        csvReader = getCSVReader(tablePath);
        while ((fields = csvReader.readNext()) != null) {
            if (fields != null) {
                row = new Orders(fields);
                writer.addRow(row);
            }
        }
        writer.close();
        closeFiles();
        System.out.println("Orders: DONE");
    }

    public void writeNationFile() throws Exception {
        String tablePath = tpchLocation + "nation.tbl";
        testFilePath = new Path(outputLocation + "nation.orc");
        fs.delete(testFilePath, false);

        ObjectInspector inspector;

        String[] fields;
        Nation row;

        synchronized (OrcFileTest.class) {
            inspector = ObjectInspectorFactory.getReflectionObjectInspector(
                    Nation.class,
                    ObjectInspectorFactory.ObjectInspectorOptions.JAVA);
        }
        Writer writer = OrcFile.createWriter(fs, testFilePath, conf, inspector,
                stripeSize, compressionKind, compressBlockSize, rowIndexStride);

        csvReader = getCSVReader(tablePath);
        while ((fields = csvReader.readNext()) != null) {
            if (fields != null) {
                row = new Nation(fields);
                writer.addRow(row);
            }
        }
        writer.close();
        closeFiles();
        System.out.println("Nation: DONE");
    }

    public void writeRegionFile() throws Exception {
        String tablePath = tpchLocation + "region.tbl";
        testFilePath = new Path(outputLocation + "region.orc");
        fs.delete(testFilePath, false);

        ObjectInspector inspector;

        String[] fields;
        Region row;

        synchronized (OrcFileTest.class) {
            inspector = ObjectInspectorFactory.getReflectionObjectInspector(
                    Region.class,
                    ObjectInspectorFactory.ObjectInspectorOptions.JAVA);
        }
        Writer writer = OrcFile.createWriter(fs, testFilePath, conf, inspector,
                stripeSize, compressionKind, compressBlockSize, rowIndexStride);

        csvReader = getCSVReader(tablePath);
        while ((fields = csvReader.readNext()) != null) {
            if (fields != null) {
                row = new Region(fields);
                writer.addRow(row);
            }
        }
        writer.close();
        closeFiles();
        System.out.println("Region: DONE");
    }

    public void writeLineitemFile() throws Exception {
        String tablePath = tpchLocation + "lineitem.tbl";
        testFilePath = new Path(outputLocation + "lineitem.orc");
        fs.delete(testFilePath, false);

        ObjectInspector inspector;

        String[] fields;
        Lineitem r;
        synchronized (OrcFileTest.class) {
            inspector = ObjectInspectorFactory.getReflectionObjectInspector(
                    Lineitem.class,
                    ObjectInspectorFactory.ObjectInspectorOptions.JAVA);
        }
        Writer writer = OrcFile.createWriter(fs, testFilePath, conf, inspector,
                stripeSize, compressionKind, compressBlockSize, rowIndexStride);

        csvReader = getCSVReader(tablePath);
        while ((fields = csvReader.readNext()) != null) {
            if (fields != null) {
                r = new Lineitem(fields);
                writer.addRow(r);
            }
        }
        writer.close();
        closeFiles();
        System.out.println("Lineitem: DONE");
    }

    public static Timestamp parseTimestampFromFields(String timestamp) {
        String[] dayFields = timestamp.split("-");
        calendar.set(Integer.parseInt(dayFields[0]),
                Integer.parseInt(dayFields[1]) - 1,
                Integer.parseInt(dayFields[2]));
        return new Timestamp(calendar.getTimeInMillis());
    }

    public static Date parseDateFromFields(String timestamp) {
        String[] dayFields = timestamp.split("-");
        calendar.set(Integer.parseInt(dayFields[0]),
                Integer.parseInt(dayFields[1]) - 1,
                Integer.parseInt(dayFields[2]));
        return new Date(calendar.getTimeInMillis());
    }
}
